##LearnBrailleWith.tech

Created by Nathan, Alee, Raleigh, and Matthew

To run, open Character to Binary -> run Character to Binary.sln
Type in what you want to say, and the connected arduino will point to the braille to read!