##LearnBrailleWith.tech

Created by Nathan, Alee, Raleigh, and Matthew

To run, open Character to Binary -> Character to Binary -> Program.cs, then use it in terminal
Type in what you want to say, and the connected arduino will point to the braille to read!